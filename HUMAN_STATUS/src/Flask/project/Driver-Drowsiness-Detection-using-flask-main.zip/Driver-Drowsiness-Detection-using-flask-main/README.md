# Driver-Drowsiness-Detection-using-flask
Web application- Driver Drowsiness Detection using flask

![image](https://github.com/Sharmishtha1907/Driver-Drowsiness-Detection-using-flask/assets/89999907/1d5ef471-1081-46f5-9cf7-8b9d3ce2d3fb)

![image](https://github.com/Sharmishtha1907/Driver-Drowsiness-Detection-using-flask/assets/89999907/953f40ab-cae4-4462-a636-2265ac86afba)

![image](https://github.com/Sharmishtha1907/Driver-Drowsiness-Detection-using-flask/assets/89999907/91b6a4b9-cdc5-4faf-976f-d4b6ce72564a)


Model link:

Dataset : MRL Eye Dataset
